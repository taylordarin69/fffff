Placeholder FlashLoan Sponsor app.
